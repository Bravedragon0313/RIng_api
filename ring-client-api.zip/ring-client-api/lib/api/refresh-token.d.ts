export declare function acquireRefreshToken(): Promise<string>;
export declare function logRefreshToken(): Promise<void>;
