export declare function logDeviceData(): Promise<void>;
