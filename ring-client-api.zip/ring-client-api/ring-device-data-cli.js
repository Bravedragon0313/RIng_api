#!/usr/bin/env node
require('./lib/api/device-data').logDeviceData()
