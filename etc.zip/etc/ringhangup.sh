#!/bin/bash
    /usr/sbin/asterisk -rvx "hangup request all"
