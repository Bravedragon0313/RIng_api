mysqladmin -u restoredefault -pFor3v3r1002! drop sigman
mysqladmin -u restoredefault -pFor3v3r1002! create sigman 
mysql -u restoredefault -pFor3v3r1002! < sqlfactorydefault.sql
