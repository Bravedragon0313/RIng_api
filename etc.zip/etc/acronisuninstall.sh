/usr/lib/Acronis/BackupAndRecovery/uninstall/uninstall
