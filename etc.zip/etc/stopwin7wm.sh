virsh shutdown b9fa4e4f-2c06-4fec-9371-0c18f71d9641-vm-1 
