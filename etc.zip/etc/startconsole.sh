
/usr/sbin/asterisk -r
exit
