sudo pkill ffserver
