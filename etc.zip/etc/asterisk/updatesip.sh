cd /etc/asterisk/
php convertsip.php
/etc/asterisk/sip_to_pjsip.py output.txt sip2pjsipexport.conf 

